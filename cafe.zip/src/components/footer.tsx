export default function Footer() {
    return (
      <footer className="dark:bg-gray-800 py-4 text-center text-muted-tan text-sm relative bottom-0 w-full">
        <p>&copy; 2025 AASTU. All rights reserved.</p>
      </footer>
    )
  }
  
  